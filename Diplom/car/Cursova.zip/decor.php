<?php require('db.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
   <title>Оформлення замовлення</title>
   <link rel="stylesheet" href="css/styles.css">

</head>

<body>
   <div class="popup__tovar">

   </div>
   <form action="core/mail.php" method="POST" class="form_active">
      <p>Введіть імя</p>
      <input type="text" name="name" id="name" required minlength="3">
      <p>Введіть прізвище</p>
      <input type="text" name="surname" id="surname" required minlength="4">
      <p>Введіть пошту</p>
      <input type="text" name="gmail" id="gmail" required>
      <p>Введіть номер телефону</p>
      <input type="tel" name="tel" id="tel" minlength="10" maxlength="10">
      <p>Виберіть місто доставки</p>
      <select name="city" id="city" class="sel_city" required>
         <option value="Київ">Київ</option>
         <option value="Львів">Львів</option>
         <option value="Полтава">Полтава</option>
         <option value="Харків">Харків</option>
         <option value="Житомир">Житомир</option>
      </select>
      <button class="send-gmail">Оформлення замовлення</button>
   </form>
   <?php

   if (isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['gmail']) && isset($_POST['tel']) && isset($_POST['city'])) {
      $name = $_POST['name'];

      $surname = $_POST['surname'];
      $gmail = $_POST['gmail'];
      $tel = $_POST['tel'];
      $city = $_POST['city'];

      $query = "INSERT INTO `owner` (`id`, `name`, `surname`, `gmail`, `phone`, `city`) VALUES (NULL, '$name', '$surname', '$gmail', '$tel', '$city');";
      mysqli_query($link, $query);
   }
   ?>



   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   <script src="js/main.js"></script>
</body>

</html>